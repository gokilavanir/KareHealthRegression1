import org.openqa.selenium.WebDriver;

public class Constants {
    public final static String URL = "http://karehealth.menpaniproducts.com/admin/auth/login";


}
